SplitReceipt

https://splitreceipt.app

Currently deploys to staging.splitreceipt.app

Install node v14.17.5, yarn

Build: yarn build

Local Environment: yarn start